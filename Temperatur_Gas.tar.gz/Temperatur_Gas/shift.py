import sys

a = b'\x98\t\xe8\x1c\n'
b = b'\xbe\x0b\xe8\x1c\n'

def shift(c):
    return (c[0]|c[1] << 8) /100