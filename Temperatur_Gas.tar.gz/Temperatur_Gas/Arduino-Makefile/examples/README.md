This folder contains the list of example Arduino sketches and makefile showing
the different usage patterns

- BlinkInAVRC - Shows how to use plain AVR C code
- ATtinyBlink - Shows how to use different cores like ATtiny
- Blink - Shows normal usage
- HelloWorld - Shows how to include Arduino libraries
- SerialPrint - Shows how serial monitor can be used
- BlinkChipKIT - Shows how to use ChipKIT
